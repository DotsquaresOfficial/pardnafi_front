import { createSlice } from "@reduxjs/toolkit";

export const myreducer=createSlice({
    name:"myrecuder",
    initialState:{},
    reducers:{}

})