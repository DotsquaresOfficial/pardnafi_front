// const baseUrl = process.env.REACT_APP_baseUrl;
const baseUrl = "https://pardnafi.24livehost.com/v1";

export { baseUrl };