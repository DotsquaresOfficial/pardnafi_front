const config = localStorage.getItem("jwtToken");

export default config;