export const role = {
    Admin: "admin",
    User: "user"
}