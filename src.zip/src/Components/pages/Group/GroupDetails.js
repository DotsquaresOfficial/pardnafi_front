import React from 'react'
import Header from '../../Widgets/Header'
import PageHeader from '../../Widgets/PageHeader'
import Footer from '../../Widgets/Footer'

const GroupDetails = () => {
  return (
    <>
      <Header />
      <PageHeader title="Group Details" text="Group Details" />
      <section className="pricing padding-top padding-bottom dash-sec">
        <div className="section-header section-header--max50">
          <h2 className="mb-15 mt-minus-5"> Group Details</h2>

        </div>

      </section>



      <Footer />
    </>
  )
}

export default GroupDetails
